function g = thr(t,x)
g = (sign(x-t)/2+.5);

