function f = exp1(t,a,tau,e)

f = a.*exp(-t./tau)+e;
